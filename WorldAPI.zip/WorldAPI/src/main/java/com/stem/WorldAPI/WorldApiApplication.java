package com.stem.WorldAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorldApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorldApiApplication.class, args);
	}

}
